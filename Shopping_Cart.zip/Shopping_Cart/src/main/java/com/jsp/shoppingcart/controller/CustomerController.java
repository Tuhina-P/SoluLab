package com.jsp.shoppingcart.controller;

import javax.servlet.ServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.shoppingcart.dao.CustomerDao;
import com.jsp.shoppingcart.dto.Customer;
import com.jsp.shoppingcart.dto.Merchant;

@Controller
public class CustomerController {
	@Autowired
	CustomerDao dao;
	@RequestMapping("/addcustomer")
	public ModelAndView addCustomer()
	{
		Customer c = new Customer();
		ModelAndView mv = new ModelAndView();
		mv.addObject("customerobj", c);
		mv.setViewName("CustomerForm");

		return mv;
	}
	@RequestMapping("/savecustomer")
	public ModelAndView saveCustomer(@ModelAttribute("customerobj") Customer c)
	{
		dao.saveCustomer(c);
		ModelAndView mv = new ModelAndView();
		mv.addObject("addCustomer", "Customer Added Successfully...");
		mv.setViewName("CustomerMenu");

		return mv;
	}
	@RequestMapping("/customerloginvalidation")
	public ModelAndView login(ServletRequest req,HttpSession session)
	{
		String email=req.getParameter("email");
		String password=req.getParameter("password");
		Customer c = dao.login(email, password);
		ModelAndView mv=new ModelAndView();
		if (c != null) {
			mv.addObject("msg", "Login Successfull...");
			mv.setViewName("CustomerOption");
			session.setAttribute("customerinfo", c);
			return mv;
		} else {
			mv.addObject("msg", "Invalid Credentials !!");
			mv.setViewName("CustomerLoginForm");
			return mv;
		}
	}
}
