package com.jsp.shoppingcart.controller;

import org.springframework.stereotype.Controller;

@Controller
public class OrdersController {

}
