package com.jsp.shoppingcart.controller;

import java.util.ArrayList;
import java.util.List;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.jsp.shoppingcart.dao.MerchantDao;
import com.jsp.shoppingcart.dao.ProductDao;
import com.jsp.shoppingcart.dto.Merchant;
import com.jsp.shoppingcart.dto.Product;

@Controller
public class ProductController {

	@Autowired
	MerchantDao mdao;

	@Autowired
	ProductDao dao;

	@RequestMapping("/addproduct")
	public ModelAndView addProduct() {
		Product p = new Product();
		ModelAndView mv = new ModelAndView();
		mv.addObject("productobj", p);
		mv.setViewName("AddProduct");

		return mv;
	}

	@RequestMapping("/saveproduct")
	public ModelAndView saveProduct(@ModelAttribute("productobj") Product p, HttpSession session) {
		Merchant m = (Merchant) session.getAttribute("merchantinfo");
		List<Product> product = m.getProducts();
		if (product.size() > 0) {
			product.add(p);
			m.setProducts(product);
		} else {
			List<Product> plist = new ArrayList<Product>();
			plist.add(p);

			m.setProducts(plist);
		}
		dao.saveProduct(p);
		mdao.updateMerchant(m);
		ModelAndView mv = new ModelAndView();
		mv.addObject("addProduct", "Product Added Successfully...");
		mv.setViewName("MerchantOptions");

		return mv;
	}

	@RequestMapping("/deleteproduct")
	public ModelAndView deleteProduct(@RequestParam("id") int id, HttpSession session) {
		Merchant merchant = (Merchant) session.getAttribute("merchantinfo");

		Merchant m = mdao.deleteProductFromMerchant(merchant.getId(), id);
		mdao.updateMerchant(m);
		dao.deleteProductById(id);
		
		session.setAttribute("merchantinfo", m);
		
		ModelAndView mv = new ModelAndView();
		mv.setViewName("ViewAllProducts");

		return mv;
	}

	@RequestMapping("/Updateform")
	public ModelAndView updateProductById(@RequestParam("id") int id) {
		Product p = dao.findProductById(id);
		ModelAndView mv = new ModelAndView();
		mv.addObject("updateproduct", p);
		mv.setViewName("UpdateForm");

		return mv;
	}

	@RequestMapping("/productupdate")
	public ModelAndView updateProduct(Product p) {
		dao.updateProduct(p);
		ModelAndView mv = new ModelAndView();
		mv.addObject("updatemsg", "Successfull...");
		mv.setViewName("redirect://Updateform");

		return mv;
	}

}
